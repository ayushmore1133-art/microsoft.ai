import "dotenv/config";

/**
 * Supports two providers so you're not stuck needing a paid Anthropic key:
 *   - "gemini"    (default) — Google AI Studio, permanent free tier, no credit card
 *   - "anthropic" — Claude, needs the one-time free trial credit or a paid key
 *
 * Switch with LLM_PROVIDER=gemini|anthropic in .env. Every route in this
 * project calls callClaudeJSON(...) below — the routes/prompts never need to
 * know which provider is actually running underneath.
 */

const PROVIDER = (process.env.LLM_PROVIDER || "gemini").toLowerCase();

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const ANTHROPIC_MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";

const MAX_TOKENS = parseInt(process.env.MAX_TOKENS || "2400", 10);
const TIMEOUT_MS = 45000;

// Free-tier keys allow only a limited number of requests per minute, but this
// app fires several calls back-to-back (4 agent opinions, then 4 debate
// calls). makeRequestQueue() gives each provider its own serialized queue so
// calls wait their turn instead of firing all at once — spaced far enough
// apart to stay under that provider's per-minute cap.
function makeRequestQueue(minIntervalMs) {
  let queue = Promise.resolve();
  return function schedule(fn) {
    const run = queue.then(() => fn());
    // Chain the *next* call to wait minIntervalMs after this one starts,
    // regardless of whether it succeeds or fails.
    queue = run.catch(() => {}).then(() => new Promise((resolve) => setTimeout(resolve, minIntervalMs)));
    return run;
  };
}

const GEMINI_MIN_INTERVAL_MS = parseInt(process.env.GEMINI_MIN_INTERVAL_MS || "13000", 10);
const scheduleGemini = makeRequestQueue(GEMINI_MIN_INTERVAL_MS);

// Groq's free tier is far more generous (30 req/min), so a short spacing is
// enough to smooth out bursts without meaningfully slowing the pipeline down.
const GROQ_MIN_INTERVAL_MS = parseInt(process.env.GROQ_MIN_INTERVAL_MS || "2000", 10);
const scheduleGroq = makeRequestQueue(GROQ_MIN_INTERVAL_MS);

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const MAX_RATE_LIMIT_RETRIES = 3;

/** Runs `fn` through `schedule`, retrying on a RATE_LIMIT error with backoff. */
async function withRateLimitRetry(schedule, fn) {
  return schedule(async () => {
    for (let attempt = 0; attempt <= MAX_RATE_LIMIT_RETRIES; attempt++) {
      try {
        return await fn();
      } catch (err) {
        if (err.code === "RATE_LIMIT" && attempt < MAX_RATE_LIMIT_RETRIES) {
          const waitMs = err.retryDelayMs || (attempt + 1) * 10000;
          await sleep(waitMs);
          continue;
        }
        throw err;
      }
    }
  });
}

/** Pulls Google's suggested retry delay (in ms) out of a 429 error body, if present. */
function parseGeminiRetryDelayMs(bodyText) {
  try {
    const parsed = JSON.parse(bodyText);
    const detail = (parsed?.error?.details || []).find((d) =>
      (d["@type"] || "").includes("RetryInfo")
    );
    const retryDelay = detail?.retryDelay; // e.g. "23s"
    if (retryDelay) {
      const secs = parseFloat(retryDelay.replace("s", ""));
      if (!isNaN(secs)) return Math.ceil(secs * 1000);
    }
  } catch {
    /* fall through to default */
  }
  return null;
}

/** Reads Groq's rate-limit headers to know how long to back off, if present. */
function parseGroqRetryDelayMs(res) {
  const retryAfter = res.headers.get("retry-after");
  if (retryAfter) {
    const secs = parseFloat(retryAfter);
    if (!isNaN(secs)) return Math.ceil(secs * 1000);
  }
  return null;
}

function withTimeout() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  return { signal: controller.signal, clear: () => clearTimeout(timer) };
}

async function callAnthropicRaw({ system, userPrompt, maxTokens, temperature }) {
  if (!ANTHROPIC_API_KEY) {
    const err = new Error(
      "Missing ANTHROPIC_API_KEY. Add it to .env, or set LLM_PROVIDER=gemini to use the free Gemini tier instead."
    );
    err.code = "NO_API_KEY";
    throw err;
  }
  const { signal, clear } = withTimeout();
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: maxTokens,
        temperature,
        system,
        messages: [{ role: "user", content: userPrompt }],
      }),
      signal,
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      const err = new Error(`Anthropic API error ${res.status}: ${bodyText.slice(0, 400)}`);
      err.code = "API_ERROR";
      err.status = res.status;
      throw err;
    }
    const data = await res.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    return textBlock ? textBlock.text : "";
  } catch (err) {
    if (err.name === "AbortError") {
      const e = new Error("Anthropic API call timed out.");
      e.code = "TIMEOUT";
      throw e;
    }
    throw err;
  } finally {
    clear();
  }
}

async function callGeminiOnce({ system, userPrompt, maxTokens, temperature }) {
  const { signal, clear } = withTimeout();
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
    const isGemini3Plus = /gemini-[3-9]/.test(GEMINI_MODEL);
    const generationConfig = {
      temperature,
      maxOutputTokens: maxTokens,
      responseMimeType: "application/json",
    };
    // Keep output tokens available for the actual answer rather than internal
    // "thinking" — field name differs between model generations.
    if (isGemini3Plus) generationConfig.thinkingConfig = { thinkingLevel: "low" };
    else generationConfig.thinkingConfig = { thinkingBudget: 0 };
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        generationConfig,
      }),
      signal,
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      const err = new Error(`Gemini API error ${res.status}: ${bodyText.slice(0, 400)}`);
      err.code = res.status === 429 ? "RATE_LIMIT" : "API_ERROR";
      err.status = res.status;
      err.retryDelayMs = res.status === 429 ? parseGeminiRetryDelayMs(bodyText) : null;
      throw err;
    }
    const data = await res.json();
    const candidate = data?.candidates?.[0];
    const parts = candidate?.content?.parts || [];
    const text = parts.map((p) => p.text || "").join("");
    if (!text.trim()) {
      const reason = candidate?.finishReason || "UNKNOWN";
      const blockReason = data?.promptFeedback?.blockReason;
      const err = new Error(
        `Gemini returned no text (finishReason: ${reason}${blockReason ? `, blockReason: ${blockReason}` : ""}). ` +
          (reason === "MAX_TOKENS"
            ? "Try raising MAX_TOKENS in .env."
            : reason === "SAFETY" || blockReason
            ? "The content was flagged by Gemini's safety filter."
            : "The response was empty.")
      );
      err.code = "EMPTY_RESPONSE";
      throw err;
    }
    return text;
  } catch (err) {
    if (err.name === "AbortError") {
      const e = new Error("Gemini API call timed out.");
      e.code = "TIMEOUT";
      throw e;
    }
    throw err;
  } finally {
    clear();
  }
}

async function callGeminiRaw(args) {
  if (!GEMINI_API_KEY) {
    const err = new Error(
      "Missing GEMINI_API_KEY. Get a free key (no credit card) at https://aistudio.google.com/apikey and add it to .env."
    );
    err.code = "NO_API_KEY";
    throw err;
  }
  // Serialize + space out calls so parallel requests from the frontend/debate
  // step don't all land in the same second and trip the free-tier RPM cap.
  return withRateLimitRetry(scheduleGemini, () => callGeminiOnce(args));
}

async function callGroqOnce({ system, userPrompt, maxTokens, temperature }) {
  const { signal, clear } = withTimeout();
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        max_tokens: maxTokens,
        temperature,
        messages: [
          { role: "system", content: system },
          { role: "user", content: userPrompt },
        ],
      }),
      signal,
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      const err = new Error(`Groq API error ${res.status}: ${bodyText.slice(0, 400)}`);
      err.code = res.status === 429 ? "RATE_LIMIT" : "API_ERROR";
      err.status = res.status;
      err.retryDelayMs = res.status === 429 ? parseGroqRetryDelayMs(res) : null;
      throw err;
    }
    const data = await res.json();
    return data?.choices?.[0]?.message?.content || "";
  } catch (err) {
    if (err.name === "AbortError") {
      const e = new Error("Groq API call timed out.");
      e.code = "TIMEOUT";
      throw e;
    }
    throw err;
  } finally {
    clear();
  }
}

async function callGroqRaw(args) {
  if (!GROQ_API_KEY) {
    const err = new Error(
      "Missing GROQ_API_KEY. Get a free key (no credit card) at https://console.groq.com/keys and add it to .env."
    );
    err.code = "NO_API_KEY";
    throw err;
  }
  return withRateLimitRetry(scheduleGroq, () => callGroqOnce(args));
}

async function callLLM(args) {
  if (PROVIDER === "anthropic") return callAnthropicRaw(args);
  if (PROVIDER === "groq") return callGroqRaw(args);
  return callGeminiRaw(args); // default: gemini
}

/**
 * Scans from the first { or [ and returns the substring up to its matching
 * closing bracket, ignoring anything the model appended after it (some
 * models add trailing commentary even when asked for JSON-only output).
 * Respects strings/escapes so braces inside quoted text don't confuse it.
 */
function extractFirstJsonValue(text) {
  const startMatch = text.match(/[{[]/);
  if (!startMatch) return null;
  const start = startMatch.index;
  const open = text[start];
  const close = open === "{" ? "}" : "]";
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null; // never closed — likely truncated output
}

/** Strip ```json fences etc, then JSON.parse. Throws if unparsable. */
function parseJsonLoose(raw) {
  let text = raw.trim();
  text = text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "");
  try {
    return JSON.parse(text);
  } catch {
    const candidate = extractFirstJsonValue(text);
    if (!candidate) throw new Error("Could not locate JSON in model response.");
    return JSON.parse(candidate);
  }
}

/**
 * Calls the configured LLM expecting a JSON response, validates it with
 * `validate`, and retries once with a stricter correction message if
 * parsing or validation fails. Same signature regardless of provider —
 * routes.js and prompts.js never need to change based on LLM_PROVIDER.
 */
export async function callClaudeJSON({ system, userPrompt, validate, maxRetries = 1, temperature = 0.4, maxTokens }) {
  let lastError = null;
  let prompt = userPrompt;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const raw = await callLLM({ system, userPrompt: prompt, maxTokens: maxTokens || MAX_TOKENS, temperature });
      const parsed = parseJsonLoose(raw);
      if (validate) validate(parsed);
      return parsed;
    } catch (err) {
      lastError = err;
      if (err.code === "NO_API_KEY") throw err; // no point retrying a missing key
      const correction = `Your previous response was invalid: ${err.message}. Respond again with ONLY valid JSON matching the required schema exactly — no markdown fences, no commentary, no missing or empty required fields.`;
      prompt = `${userPrompt}\n\n---\n${correction}`;
    }
  }

  const finalErr = new Error(
    `Model did not return valid JSON after ${maxRetries + 1} attempt(s): ${lastError?.message}`
  );
  finalErr.cause = lastError;
  throw finalErr;
}

export const activeProvider = PROVIDER;
