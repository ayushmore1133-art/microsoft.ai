import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = path.join(__dirname, "..", "data", "sessions.json");

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter, { sessions: [] });

// The 4 parallel agent-opinion calls (and the 4 parallel debate calls) can
// each try to read-modify-write the same session concurrently. Without
// serializing, one write can clobber another's changes. This queue makes
// every db operation wait its turn.
let dbQueue = Promise.resolve();
function enqueue(fn) {
  const run = dbQueue.then(fn);
  dbQueue = run.catch(() => {}); // don't let one failure block the queue forever
  return run;
}

async function init() {
  await db.read();
  db.data ||= { sessions: [] };
  await db.write();
}
await init();

export async function createSession({ candidateName, roleApplied, resumeText, transcriptText }) {
  return enqueue(async () => {
    await db.read();
    const session = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      candidateName: candidateName || "Unknown Candidate",
      roleApplied: roleApplied || "",
      resumeText,
      transcriptText,
      candidateProfile: null,
      opinions: {},
      debate: {},
      finalDecision: null,
    };
    db.data.sessions.push(session);
    await db.write();
    return session;
  });
}

export async function updateSession(id, patch) {
  return enqueue(async () => {
    await db.read();
    const session = db.data.sessions.find((s) => s.id === id);
    if (!session) return null;
    Object.assign(session, patch);
    await db.write();
    return session;
  });
}

export async function getSession(id) {
  await db.read();
  return db.data.sessions.find((s) => s.id === id) || null;
}

export async function listSessions() {
  await db.read();
  // Return lightweight summaries, most recent first.
  return [...db.data.sessions]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((s) => ({
      id: s.id,
      createdAt: s.createdAt,
      candidateName: s.candidateName,
      roleApplied: s.roleApplied,
      recommendation: s.finalDecision?.recommendation || null,
      confidence: s.finalDecision?.confidence ?? null,
    }));
}
