import { Router } from "express";
import { callClaudeJSON } from "./anthropicClient.js";
import { sanitizeText } from "./sanitize.js";
import {
  AGENT_TYPES,
  AGENT_META,
  EXTRACT_SYSTEM_PROMPT,
  buildExtractUserPrompt,
  getAgentSystemPrompt,
  buildAgentUserPrompt,
  buildDebateSystemPrompt,
  buildDebateUserPrompt,
  JUDGE_SYSTEM_PROMPT,
  buildJudgeUserPrompt,
} from "./prompts.js";
import { createSession, updateSession, getSession, listSessions } from "./db.js";
import { SEED_CANDIDATE_NAME, SEED_ROLE, SEED_RESUME, SEED_TRANSCRIPT } from "./seedData.js";

export const router = Router();

const VERDICTS = new Set(["strong_hire", "hire", "hold", "no_hire"]);

function asyncHandler(fn) {
  return (req, res, next) => fn(req, res, next).catch(next);
}

// ---------------------------------------------------------------------------
// Demo dataset — lets the panel run instantly with no upload
// ---------------------------------------------------------------------------
router.get(
  "/demo-data",
  asyncHandler(async (req, res) => {
    res.json({
      candidateName: SEED_CANDIDATE_NAME,
      roleApplied: SEED_ROLE,
      resumeText: SEED_RESUME,
      transcriptText: SEED_TRANSCRIPT,
    });
  })
);

// ---------------------------------------------------------------------------
// 1. POST /api/extract
// ---------------------------------------------------------------------------
router.post(
  "/extract",
  asyncHandler(async (req, res) => {
    const { resumeText, transcriptText, candidateName, roleApplied } = req.body || {};
    if (!resumeText || !transcriptText) {
      return res.status(400).json({ error: "resumeText and transcriptText are required." });
    }

    const cleanResume = sanitizeText(resumeText);
    const cleanTranscript = sanitizeText(transcriptText);

    const candidateProfile = await callClaudeJSON({
      system: EXTRACT_SYSTEM_PROMPT,
      userPrompt: buildExtractUserPrompt(cleanResume, cleanTranscript),
      validate: (parsed) => {
        for (const key of ["skills", "experience", "claims", "contradictions"]) {
          if (!Array.isArray(parsed[key])) {
            throw new Error(`Field "${key}" must be an array.`);
          }
        }
      },
    });

    const session = await createSession({
      candidateName,
      roleApplied,
      resumeText: cleanResume,
      transcriptText: cleanTranscript,
    });
    await updateSession(session.id, { candidateProfile });

    res.json({ sessionId: session.id, candidateProfile });
  })
);

// ---------------------------------------------------------------------------
// 2. POST /api/agent-opinion  (frontend calls this 4x in parallel)
// ---------------------------------------------------------------------------
router.post(
  "/agent-opinion",
  asyncHandler(async (req, res) => {
    const { sessionId, candidateProfile, agentType } = req.body || {};
    if (!candidateProfile || !AGENT_TYPES.includes(agentType)) {
      return res.status(400).json({ error: `agentType must be one of: ${AGENT_TYPES.join(", ")}` });
    }

    const opinion = await callClaudeJSON({
      system: getAgentSystemPrompt(agentType),
      userPrompt: buildAgentUserPrompt(candidateProfile),
      validate: (parsed) => {
        if (!VERDICTS.has(parsed.verdict)) throw new Error(`Invalid verdict "${parsed.verdict}".`);
        if (typeof parsed.confidence !== "number" || parsed.confidence < 0 || parsed.confidence > 100) {
          throw new Error("confidence must be a number 0-100.");
        }
        if (!parsed.reasoning || typeof parsed.reasoning !== "string") {
          throw new Error("reasoning must be a non-empty string.");
        }
        if (!Array.isArray(parsed.quotes) || parsed.quotes.length === 0) {
          throw new Error("quotes must be a non-empty array — every claim must be evidence-backed.");
        }
      },
    });

    const result = { agentType, label: AGENT_META[agentType].label, ...opinion };

    if (sessionId) {
      const session = await getSession(sessionId);
      if (session) {
        const opinions = { ...session.opinions, [agentType]: result };
        await updateSession(sessionId, { opinions });
      }
    }

    res.json(result);
  })
);

// ---------------------------------------------------------------------------
// 3. POST /api/debate
// ---------------------------------------------------------------------------
router.post(
  "/debate",
  asyncHandler(async (req, res) => {
    const { sessionId, allFourOpinions } = req.body || {};
    if (!allFourOpinions || AGENT_TYPES.some((t) => !allFourOpinions[t])) {
      return res.status(400).json({ error: "allFourOpinions must include all four agent types." });
    }

    const otherLabels = (agentType) =>
      AGENT_TYPES.filter((t) => t !== agentType).map((t) => AGENT_META[t].label.toLowerCase());

    const debateCalls = AGENT_TYPES.map((agentType) =>
      callClaudeJSON({
        system: buildDebateSystemPrompt(agentType),
        userPrompt: buildDebateUserPrompt(agentType, allFourOpinions[agentType], allFourOpinions),
        validate: (parsed) => {
          if (!VERDICTS.has(parsed.updatedVerdict)) {
            throw new Error(`Invalid updatedVerdict "${parsed.updatedVerdict}".`);
          }
          if (
            typeof parsed.updatedConfidence !== "number" ||
            parsed.updatedConfidence < 0 ||
            parsed.updatedConfidence > 100
          ) {
            throw new Error("updatedConfidence must be a number 0-100.");
          }
          if (!AGENT_TYPES.includes(parsed.respondedTo) || parsed.respondedTo === agentType) {
            throw new Error(
              `respondedTo must name a DIFFERENT agentType from: ${AGENT_TYPES.filter((t) => t !== agentType).join(", ")}`
            );
          }
          const rebuttal = (parsed.rebuttal || "").toLowerCase();
          const mentionsAnother =
            otherLabels(agentType).some((label) => rebuttal.includes(label)) ||
            AGENT_TYPES.filter((t) => t !== agentType).some((t) => rebuttal.includes(t.replace("_", " ")));
          if (!mentionsAnother) {
            throw new Error(
              "rebuttal must explicitly name one of the other three agents (e.g. mention 'Skeptic Agent') — restating your own opinion is not a debate."
            );
          }
        },
      }).then((opinion) => [
        agentType,
        {
          agentType,
          label: AGENT_META[agentType].label,
          quotes: allFourOpinions[agentType].quotes || [],
          ...opinion,
        },
      ])
    );

    const settled = await Promise.all(debateCalls);
    const debatedOpinions = Object.fromEntries(settled);

    if (sessionId) {
      const session = await getSession(sessionId);
      if (session) await updateSession(sessionId, { debate: debatedOpinions });
    }

    res.json({ debatedOpinions });
  })
);

// ---------------------------------------------------------------------------
// 4. POST /api/final-decision
// ---------------------------------------------------------------------------
router.post(
  "/final-decision",
  asyncHandler(async (req, res) => {
    const { sessionId, debatedOpinions } = req.body || {};
    if (!debatedOpinions || AGENT_TYPES.some((t) => !debatedOpinions[t])) {
      return res.status(400).json({ error: "debatedOpinions must include all four agent types." });
    }

    const finalDecision = await callClaudeJSON({
      system: JUDGE_SYSTEM_PROMPT,
      userPrompt: buildJudgeUserPrompt(debatedOpinions),
      validate: (parsed) => {
        if (!VERDICTS.has(parsed.recommendation)) {
          throw new Error(`Invalid recommendation "${parsed.recommendation}".`);
        }
        if (typeof parsed.confidence !== "number" || parsed.confidence < 0 || parsed.confidence > 100) {
          throw new Error("confidence must be a number 0-100.");
        }
        for (const key of ["strengths", "concerns", "unresolvedDisagreements"]) {
          if (!Array.isArray(parsed[key])) throw new Error(`Field "${key}" must be an array.`);
        }
        if (!parsed.weightingRationale || typeof parsed.weightingRationale !== "string") {
          throw new Error("weightingRationale must be a non-empty string explaining the weighing.");
        }
      },
    });

    if (sessionId) {
      const session = await getSession(sessionId);
      if (session) await updateSession(sessionId, { finalDecision });
    }

    res.json(finalDecision);
  })
);

// ---------------------------------------------------------------------------
// Session read routes — for inspecting/replaying past runs
// ---------------------------------------------------------------------------
router.get(
  "/sessions",
  asyncHandler(async (req, res) => {
    res.json(await listSessions());
  })
);

router.get(
  "/sessions/:id",
  asyncHandler(async (req, res) => {
    const session = await getSession(req.params.id);
    if (!session) return res.status(404).json({ error: "Session not found." });
    res.json(session);
  })
);
