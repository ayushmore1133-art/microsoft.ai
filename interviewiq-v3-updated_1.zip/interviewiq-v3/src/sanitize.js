/**
 * Very lightweight prompt-injection defense for user-uploaded resume/transcript text.
 * This is NOT a complete defense — it just strips the most common override phrases
 * before the text is embedded inside an LLM prompt, and caps length so one file
 * can't blow the context budget.
 */

const INJECTION_PATTERNS = [
  /ignore\s+(all|any|the)?\s*(previous|prior|above|earlier)\s+instructions?/gi,
  /disregard\s+(all|any|the)?\s*(previous|prior|above|earlier)\s+(instructions?|prompt)/gi,
  /forget\s+(everything|all)\s+(you were told|above|before)/gi,
  /you\s+are\s+now\s+[a-z0-9 ,.'"-]{0,40}/gi,
  /system\s*prompt\s*:/gi,
  /new\s+instructions?\s*:/gi,
  /act\s+as\s+(if\s+you\s+are\s+)?(a|an)\s+[a-z0-9 ,.'"-]{0,40}/gi,
  /<\s*\/?\s*(system|assistant|user)\s*>/gi,
  /```(system|assistant)/gi,
];

const MAX_LEN = 12000; // characters, per document

export function sanitizeText(input) {
  if (typeof input !== "string") return "";
  let text = input.slice(0, MAX_LEN);
  for (const pattern of INJECTION_PATTERNS) {
    text = text.replace(pattern, "[REDACTED]");
  }
  return text.trim();
}
