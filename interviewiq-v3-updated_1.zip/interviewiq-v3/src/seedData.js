export const SEED_CANDIDATE_NAME = "Maria Garcia";
export const SEED_ROLE = "Senior Backend Engineer";

export const SEED_RESUME = `MARIA GARCIA
Senior Backend Engineer
M.S. Computer Science — Stanford University

EXPERIENCE
Staff Engineer, Nimbus Cloud (2022–Present)
- Led migration of 40 microservices from a monolith to Kubernetes, reducing deploy time by 65%.
- Owned production reliability for the payments platform; on-call rotation lead for 18 months.
- Designed the internal event bus used by 12 teams; wrote the RFC and drove adoption end to end.

Senior Backend Engineer, Fintra (2019–2022)
- Sole backend owner of the fraud-scoring service handling 4M requests/day.
- Mentored 3 junior engineers; two were promoted within a year of working with me.

SKILLS
Python, Go, Kubernetes, PostgreSQL, Kafka, Distributed Systems, AWS, Terraform

EDUCATION
M.S. Computer Science, Stanford University, 2019
B.S. Computer Science, UC San Diego, 2017`;

export const SEED_TRANSCRIPT = `INTERVIEWER: Walk me through the Kubernetes migration you mentioned on your resume.

CANDIDATE: Sure. At Nimbus we had a single Django monolith that was basically impossible to deploy
safely — one bad change and everything went down. I led the migration of 40 microservices onto
Kubernetes over about nine months. I personally wrote the rollout runbooks and the rollback strategy
for the payments-critical services, since those couldn't tolerate downtime.

INTERVIEWER: You said you "led" it — was that a solo effort or did you have a team?

CANDIDATE: I had a team of five, but I was the tech lead and wrote the core migration tooling myself.
I made the call on sequencing which services moved first based on risk.

INTERVIEWER: Tell me about a time something went wrong in production.

CANDIDATE: During the fraud-scoring rollout at Fintra, we pushed a model update that had a subtle bug —
it started flagging almost 20% of legitimate transactions as fraud. I noticed it within 40 minutes
because I had built alerting on the false-positive rate specifically for this reason. I rolled it back
myself, then wrote a full postmortem and we added a canary stage that would have caught it automatically
next time.

INTERVIEWER: How do you handle disagreements with teammates on technical direction?

CANDIDATE: Honestly, I used to just push my opinion hard because I was usually right technically. That
didn't always land well with more junior folks. Over the last couple years I've gotten a lot more
deliberate about writing an RFC first, listing trade-offs, and asking people to poke holes in it before
I commit. It slows me down a little but the team trusts the decisions more.

INTERVIEWER: You mentioned mentoring on your resume — can you say more?

CANDIDATE: I mentored three junior engineers at Fintra. Two got promoted to mid-level within a year.
The third moved teams before I could really see it through, so I can't take full credit there.

INTERVIEWER: Last one — why leave Nimbus?

CANDIDATE: Honestly, the on-call load has been heavy for a long stretch — 18 months as rotation lead —
and I want a role with a bit more balance while I keep growing technically. I'm not leaving because of
any conflict, I just want the next chapter to look a little different.`;
